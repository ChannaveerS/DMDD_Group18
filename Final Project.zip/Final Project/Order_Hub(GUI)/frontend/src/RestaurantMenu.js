import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';
import { Container, Card, Table, Button, Form,Toast, ToastHeader, ToastBody} from 'react-bootstrap';

const RestaurantMenu = () => {
    const { customerID, restaurantID } = useParams(); // Extract customerID and restaurantID from URL
    const [menus, setMenus] = useState([]);
    const [cart, setCart] = useState([]);
    const [showToast, setShowToast] = useState(false);
    const [paymentInfo, setPaymentInfo] = useState({
        TypeOfPayment: '',
        PaymentAmount: 0
    });

    useEffect(() => {
        const fetchMenus = async () => {
            try {
                const response = await axios.get(`http://localhost:3000/api/restaurants/${restaurantID}/menus`);
                setMenus(response.data);
            } catch (error) {
                console.error('Error fetching menus:', error);
            }
        };
        fetchMenus();
    }, [restaurantID]);

    const addToCart = (item) => {
        const updatedCart = [...cart];
        const index = updatedCart.findIndex(cartItem => cartItem.MenuItemsID === item.MenuItemsID);
        if (index !== -1) {
            updatedCart[index].quantity++;
        } else {
            updatedCart.push({ ...item, quantity: 1 });
        }
        setCart(updatedCart);
    };

    const removeFromCart = (item) => {
        const updatedCart = [...cart];
        const index = updatedCart.findIndex(cartItem => cartItem.MenuItemsID === item.MenuItemsID);
        if (index !== -1) {
            updatedCart.splice(index, 1);
            setCart(updatedCart);
        }
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setPaymentInfo(prevState => ({
            ...prevState,
            [name]: value
        }));
    };

    const getTotalPrice = () => {
        return cart.reduce((total, item) => total + (item.ItemPrice * item.quantity), 0);
    };

    const confirmPayment = async () => {
        try {
            // Create the payment object
            const paymentData = {
                customerId: customerID, // Use extracted customerID from URL
                restaurantId: restaurantID,
                menuItems: cart,
                comments: ''
            };
            // Make the payment
            const paymentResponse = await axios.post('http://localhost:3000/api/payment', paymentData);
            console.log(paymentResponse.data); // Assuming the server returns the payment response

            // Clear the cart and reset payment info after successful payment
            setCart([]);
            setPaymentInfo({
                TypeOfPayment: '',
                PaymentAmount: 0
            });
            console.log('SUCCESS Payment')
            if(paymentResponse.data.success){ // Check success from response
                setShowToast(true); 
            }
            // Optionally, you can redirect the user to a success page
        } catch (error) {
            console.error('Error confirming payment:', error);
        }
    };

    return (
        <Container>
            <h2 className="mt-4">Restaurant Menu</h2>
            {menus.map(menu => (
                <Card key={menu.MenuID} className="mb-4">
                    <Card.Header className="bg-primary text-white">{menu.MenuType}</Card.Header>
                    <Card.Body>
                        <Table striped bordered hover responsive>
                            <thead>
                                <tr>
                                    <th>Item Name</th>
                                    <th>Description</th>
                                    <th>Price</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                {menu.MenuItems.map(item => (
                                    <tr key={item.MenuItemsID}>
                                        <td>{item.ItemName}</td>
                                        <td>{item.ItemDescription}</td>
                                        <td>${item.ItemPrice}</td>
                                        <td>
                                            <Button variant="primary" onClick={() => addToCart(item)}>Add to Cart</Button>{' '}
                                            <Button variant="danger" onClick={() => removeFromCart(item)}>Remove</Button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </Table>
                    </Card.Body>
                </Card>
            ))}
            {cart.length > 0 && (
                <div>
                    <h3>Cart</h3>
                    <Table striped bordered hover responsive>
                        <thead>
                            <tr>
                                <th>Item Name</th>
                                <th>Quantity</th>
                                <th>Price</th>
                            </tr>
                        </thead>
                        <tbody>
                            {cart.map(item => (
                                <tr key={item.MenuItemsID}>
                                    <td>{item.ItemName}</td>
                                    <td>{item.quantity}</td>
                                    <td>${item.ItemPrice * item.quantity}</td>
                                </tr>
                            ))}
                        </tbody>
                    </Table>
                    <p><strong>Total Amount: ${getTotalPrice()}</strong></p>
                    <Button variant="success" className="mb-4" onClick={() => console.log('Proceed to Payment clicked')}>Proceed to Payment</Button>
                </div>
            )}
            {cart.length > 0 && (
                <div>
                    <h3>Payment Information</h3>
                    <Form>
                        <Form.Group className="mb-3">
                            <Form.Label>Type of Payment</Form.Label>
                            <Form.Control type="text" name="TypeOfPayment" value={paymentInfo.TypeOfPayment} onChange={handleInputChange} />
                        </Form.Group>
                        <Button variant="primary" onClick={confirmPayment}>Confirm Payment</Button>
                    </Form>
                </div>
            )}
            <Toast
    show={showToast}
    onClose={() => setShowToast(false)}
    className="position-absolute top-50 start-50 translate-middle p-3"
    style={{ zIndex: 11, backgroundColor: '#5cb85c', color: 'white', maxWidth: '300px' }}
>
    <Toast.Header closeButton={true}>
        <strong className="me-auto">Order Confirmation</strong>
    </Toast.Header>
    <Toast.Body>
        <p>Payment successful!</p>
        <p>Expect your delicious delivery in approximately 40 minutes.</p>
    </Toast.Body>
</Toast>

        </Container>
    );
};

export default RestaurantMenu;
