import React from 'react';
import { Button } from 'react-bootstrap';
import { useNavigate } from "react-router-dom";
import backgroundImage from './images/homepage.webp'; // Adjust the path according to where you saved your image

function HomePage() {

  const navigate = useNavigate();
  return (
    <div style={{
      height: '100vh',
      background: `url(${backgroundImage}) no-repeat center center fixed`,
      backgroundSize: 'cover',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      alignItems: 'center',
    }}>
      <Button variant="primary" size="lg" onClick={()=>navigate("/login")}>
        Login 
      </Button>
    </div>
  );
}

export default HomePage;
