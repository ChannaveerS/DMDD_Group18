// RestaurantList.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Container, Row, Col, Card } from 'react-bootstrap';
// import './RestaurantList.css'; // Import custom CSS file

const Restaurant = () => {
    const [restaurants, setRestaurants] = useState([]);

    useEffect(() => {
        const fetchRestaurants = async () => {
            try {
                const response = await axios.get('http://localhost:3000/api/restaurants');
                setRestaurants(response.data);
            } catch (error) {
                console.error('Error fetching restaurants:', error);
            }
        };
        fetchRestaurants();
    }, []);

    return (
        <Container>
            <h2 className="my-4">Restaurants</h2>
            <Row xs={1} md={2} lg={3} className="g-4">
                {restaurants.map(restaurant => (
                    <Col key={restaurant.RestaurantID}>
                        <Card className="custom-card">
                            <Card.Body>
                                <Card.Title>{restaurant.RestaurantName}</Card.Title>
                                <Card.Text>Contact No: {restaurant.RestaurantContactNo}</Card.Text>
                                <Card.Text>Address: {restaurant.RestaurantStreet}, {restaurant.RestaurantCity}, {restaurant.RestaurantState} - {restaurant.RestaurantZipCode}</Card.Text>
                                <Card.Text>Type: {restaurant.RestaurantType}</Card.Text>
                                <Card.Text>Is Open: {restaurant.IsOpen}</Card.Text>
                            </Card.Body>
                        </Card>
                    </Col>
                ))}
            </Row>
        </Container>
    );
};

export default Restaurant;
